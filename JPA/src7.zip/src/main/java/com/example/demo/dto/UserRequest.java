/**
 * 3
 */
package com.example.demo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import com.example.demo.entity.User;

import lombok.Data;

@Data
public class UserRequest {
	// 3-1 バリデーションの追加
    @NotBlank(message = "名前は必須です")
    @Size(max = 100, message = "名前は100文字以内")
    private String name;

    @NotBlank(message = "メールは必須です")
    @Email(message = "メール形式が不正です")
    private String email;
    // 7追加
    @NotBlank(message = "パスワードは必須です")
    @Size(max = 100, message = "パスワードは100文字以内")
    private String password;

    // DTO → Entity
    public User toEntity() {
        User user = new User();
        user.setName(this.name);
        user.setEmail(this.email);
        user.setPassword(this.password); // 7追加
        return user;
    }

    // 既存Entity更新用
    public void updateEntity(User user) {
        user.setName(this.name);
        user.setEmail(this.email);
        if (this.password != null && !this.password.isBlank()) {	// 7追加
            user.setPassword(this.password); 
        }
    }
}
