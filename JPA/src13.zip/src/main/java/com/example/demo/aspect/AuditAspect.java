/**
 * 12
 */
package com.example.demo.aspect;

import java.time.LocalDateTime;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.example.demo.entity.AuditLog;
import com.example.demo.repository.AuditLogRepository;

@Aspect
@Component
public class AuditAspect {

    private final AuditLogRepository repo;

    public AuditAspect(AuditLogRepository repo) {
        this.repo = repo;
    }

    @AfterReturning("@annotation(audit)")
    public void logAction(Audit audit) {

        var auth = SecurityContextHolder.getContext().getAuthentication();

        String username = "anonymous";
        if (auth != null && auth.isAuthenticated()) {
            username = auth.getName();
        }

        AuditLog log = new AuditLog();
        log.setUsername(username);
        log.setAction(audit.value());
        log.setTimestamp(LocalDateTime.now());

        repo.save(log);
    }
}