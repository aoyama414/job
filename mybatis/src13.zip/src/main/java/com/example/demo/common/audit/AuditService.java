/**
 * 13追加
 */
package com.example.demo.common.audit;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuditService {
    private final AuditMapper auditMapper;
    public void save(AuditLog log) {
        auditMapper.insert(log);
    }
}