package com.example.demo.common.exception;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

	// 業務例外
	//    @ExceptionHandler(ApiException.class)
	//    public ResponseEntity<ApiError> handleApiException(ApiException ex) {
	//        ErrorCode errorCode = ex.getErrorCode();
	//
	//        log.warn("Business error: {}", ex.getMessage());
	//
	//        return ResponseEntity
	//                .status(errorCode.getStatus())
	//                .body(ApiError.builder()
	//                        .code(errorCode.getCode())
	//                        .message(ex.getMessage())
	//                        .build());
	//    }

	@ExceptionHandler(ApiException.class)
	public ResponseEntity<ApiError> handleApiException(ApiException ex) {

		ErrorCode errorCode = ex.getErrorCode();

		log.warn("Business error: {}", ex.getMessage());

		return ResponseEntity
				.status(errorCode.getStatus())
				.body(ApiError.builder()
						.code(errorCode.getCode())
						.message(errorCode.getMessage())
						.build());
	}

	// バリデーション
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ApiError> handleValidation(MethodArgumentNotValidException ex) {
		
		log.warn("Valid error: {}", ex.getMessage());

		List<FieldErrorDetail> errors = ex.getBindingResult()
				.getFieldErrors()
				.stream()
				.map(e -> new FieldErrorDetail(
						e.getField(),
						e.getDefaultMessage()))
				.toList();

		return ResponseEntity.badRequest().body(
				ApiError.builder()
						.code("VALIDATION_ERROR")
						.message("入力エラーがあります")
						.errors(errors)
						.build());
	}

	// システム例外
	// 14削除
	//	@ExceptionHandler(Exception.class)
	//	public ResponseEntity<ApiError> handleException(Exception ex) {
	//
	//		log.error("System error", ex);
	//
	//		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	//				.body(ApiError.builder()
	//						.code("SYSTEM_ERROR")
	//						.message("システムエラーが発生しました")
	//						.build());
	//	}

	/**
	 * 14 追加
	 * @param ex
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ApiError handleException(Exception ex) {
		log.error("SYSTEM ERROR", ex); // stacktraceあり
		return ApiError.builder()
				.code("SYSTEM_ERROR")
				.message("システムエラー")
				.build();
	}

}