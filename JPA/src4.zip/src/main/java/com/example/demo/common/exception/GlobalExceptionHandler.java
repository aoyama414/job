/**
 * 4
 */
package com.example.demo.common.exception;

import java.time.LocalDateTime;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.demo.dto.ErrorResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	
    // 400（バリデーション）
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse handleValidation(
            MethodArgumentNotValidException ex,
            HttpServletRequest request) {

        String message = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(e -> e.getField() + ": " + e.getDefaultMessage())
                .findFirst()
                .orElse("Validation error");

        return ErrorResponse.builder()
                .timestamp(LocalDateTime.now())
                .status(400)
                .error("VALIDATION_ERROR")
                .message(message)
                .path(request.getRequestURI())
                .build();
    }
	
	 // 404
	@ExceptionHandler(NotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse handleNotFound(
			NotFoundException ex,
			HttpServletRequest request) {
		return ErrorResponse.builder()
				.timestamp(LocalDateTime.now())
				.status(404)
				.error("NOT_FOUND")
				.message(ex.getMessage())
				.path(request.getRequestURI())
				.build();
	}

	// 400
	@ExceptionHandler(BadRequestException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorResponse handleBadRequest(
			BadRequestException ex,
			HttpServletRequest request) {
		return ErrorResponse.builder()
				.timestamp(LocalDateTime.now())
				.status(400)
				.error("BAD_REQUEST")
				.message(ex.getMessage())
				.path(request.getRequestURI())
				.build();
	}

	// 500（最後の砦）
	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ErrorResponse handleException(
			Exception ex,
			HttpServletRequest request) {
		return ErrorResponse.builder()
				.timestamp(LocalDateTime.now())
				.status(500)
				.error("INTERNAL_SERVER_ERROR")
				.message(ex.getMessage())
				.path(request.getRequestURI())
				.build();
	}
}