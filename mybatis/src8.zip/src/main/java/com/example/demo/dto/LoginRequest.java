/**
 * 
 */
package com.example.demo.dto;
import jakarta.validation.constraints.NotBlank;

import lombok.Data;
@Data
public class LoginRequest {
    @NotBlank(message = "メールは必須です")
    private String email;
    @NotBlank(message = "パスワードは必須です")
    private String password;
}
