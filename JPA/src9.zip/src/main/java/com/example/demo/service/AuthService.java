/**
 * 7
 */
package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.dto.LoginRequest;
import com.example.demo.entity.RefreshToken;
import com.example.demo.entity.User;
import com.example.demo.repository.RefreshTokenRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JwtUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthService {
	private final UserRepository repo;
	private final PasswordEncoder encoder;
	private final JwtUtil jwtUtil;
	private final RefreshTokenRepository refreshRepo;

	@Transactional
	public Map<String, String> login(LoginRequest req) {
		User user = repo.findByEmail(req.getEmail())
				.orElseThrow(() -> new ResponseStatusException(
						HttpStatus.UNAUTHORIZED,
						"メールとパスワード確認してください"));

		if (!encoder.matches(req.getPassword(), user.getPassword())) {
			throw new ResponseStatusException(
					HttpStatus.UNAUTHORIZED,
					"メールとパスワード確認してください");
		}
		String accessToken = jwtUtil.generateAccessToken(user.getEmail(), user.getRole().name()); // 9
		String refreshToken = jwtUtil.generateRefreshToken(); //9
		// DB保存
		RefreshToken token = new RefreshToken();
		token.setToken(refreshToken);
		token.setEmail(user.getEmail());
		token.setExpiryDate(LocalDateTime.now().plusDays(7));
		refreshRepo.deleteByEmail(user.getEmail());
		refreshRepo.save(token);
		return Map.of(
				"accessToken", accessToken,
				"refreshToken", refreshToken);
	}
	
	/**
	 * 8で作成、9で修正
	 * @param refreshToken
	 * @return
	 */
	public String refresh(String refreshToken) {
	    RefreshToken token = refreshRepo.findByToken(refreshToken)
	            .orElseThrow(() -> new RuntimeException("Invalid refresh token"));
//	    if (token.getExpiryDate().isBefore(LocalDateTime.now())) {
//	        throw new RuntimeException("Refresh token expired");
//	    }
	    
	    if (token == null) {
	        throw new RuntimeException("Token not found");
	    }

	    if (token.getExpiryDate().isBefore(LocalDateTime.now())) {
	        throw new RuntimeException("Token expired");
	    }
		
		
		User user = repo.findByEmail(token.getEmail())
				  .orElseThrow(() -> new RuntimeException("User not found"));
		return jwtUtil.generateAccessToken(user.getEmail(), user.getRole().name());	    
	}
	

	
	
	
	
	
	

}
