/**
 * 
 */
package com.example.demo.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.PageResponse;
import com.example.demo.dto.UserRequest;
import com.example.demo.dto.UserRequest2;
import com.example.demo.entity.User;
import com.example.demo.service.UserService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {
	private final UserService userService;
	private final PasswordEncoder passwordEncoder;

	@GetMapping
	public List<User> getAll() {
		return userService.findAll();
	}

	@GetMapping("/{id}")
	public User getById(@PathVariable Long id) {
		return userService.findById(id);
	}

	@PostMapping
	public User create(@Valid @RequestBody UserRequest request) {
		User user = new User();
		user.setName(request.getName());
		user.setEmail(request.getEmail());
		// 7で追加
		user.setRole(request.getRole());
		String encodedPassword = passwordEncoder.encode(request.getPassword());
		user.setPassword(encodedPassword);
		return userService.create(user);
	}

	@PutMapping("/{id}")
	public User update(@PathVariable Long id, @RequestBody UserRequest2 request) {
		User user = new User();
		user.setId(id);
		user.setName(request.getName());
		// 7で追加
		user.setRole(request.getRole());
		// user.setEmail(request.getEmail());
		return userService.update(user);
	}

	@DeleteMapping("/{id}")
	public void delete(@PathVariable Long id) {
		userService.delete(id);
	}
	
	@GetMapping("/page")
	public PageResponse<User> getUsers(
	        @RequestParam(defaultValue = "1") int page,
	        @RequestParam(defaultValue = "10") int size
	) {
	    return userService.findPage(page, size);
	}
}