/**
 * 
 */
package com.example.demo.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.demo.service.CustomUserDetailsService;

import io.jsonwebtoken.io.IOException;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {
	//	private final JwtUtil jwtUtil;
	//
	//	@Override
	//	protected void doFilterInternal(HttpServletRequest request,
	//			HttpServletResponse response,
	//			FilterChain filterChain)
	//			throws ServletException, IOException {
	//		String header = request.getHeader("Authorization");
	//		if (header != null && header.startsWith("Bearer ")) {
	//			String token = header.substring(7);
	//			String email = jwtUtil.extractEmail(token);
	//			// 7追加
	//			String role = jwtUtil.extractRole(token);
	//			System.out.println("role=" + role);
	//			UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
	//					email,
	//					null,
	//					List.of(new SimpleGrantedAuthority("ROLE_" + role)));
	//			SecurityContextHolder.getContext().setAuthentication(auth);
	//			//　7で削除
	//			//            UsernamePasswordAuthenticationToken auth =
	//			//                    new UsernamePasswordAuthenticationToken(email, null, List.of());
	//			//            SecurityContextHolder.getContext().setAuthentication(auth);
	//		}
	//
	//		try {
	//			filterChain.doFilter(request, response);
	//		} catch (java.io.IOException | ServletException e) {
	//			// TODO 自動生成された catch ブロック
	//			e.printStackTrace();
	//		}
	//
	//	}

	/**
	 * 13修正
	 */
	private final JwtUtil jwtUtil;
	private final CustomUserDetailsService userDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request,
			HttpServletResponse response,
			FilterChain filterChain)
			throws ServletException, IOException {

		String header = request.getHeader("Authorization");

		if (header != null && header.startsWith("Bearer ")) {
			String token = header.substring(7);

			String email = jwtUtil.extractEmail(token);

			// ★ 既に認証済みでない場合のみセット
			if (email != null && SecurityContextHolder.getContext().getAuthentication() == null) {

				// 処理をここに統合
				CustomUserDetails userDetails = (CustomUserDetails) userDetailsService.loadUserByUsername(email);

				UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
						userDetails,
						null,
						userDetails.getAuthorities());

				auth.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

				SecurityContextHolder.getContext().setAuthentication(auth);
			}
		}

		try {
			filterChain.doFilter(request, response);
		} catch (java.io.IOException | ServletException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}
}
