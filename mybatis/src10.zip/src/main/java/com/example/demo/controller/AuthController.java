/**
 * 
 */
package com.example.demo.controller;

import java.util.Map;

import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.LoginRequest;
import com.example.demo.dto.RefreshRequest;
import com.example.demo.dto.RefreshResponse;
import com.example.demo.service.AuthService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {
	private final AuthService authService;
	//　10で削除    
	//    @PostMapping("/login")
	//    public LoginResponse login(@Valid @RequestBody LoginRequest request) {
	//        String token = authService.login(request.getEmail(), request.getPassword());
	//        return new LoginResponse(token);
	//    } 

	/**
	 * 10 追加
	 * @param request
	 * @return
	 */
	// ログイン
	@PostMapping("/login")
	public Map<String, String> login(@Valid @RequestBody LoginRequest request) {
		return authService.login(request.getEmail(), request.getPassword());
	}
	
	/**
	 * 10 追加
	 * @param request
	 * @return
	 */

	// リフレッシュ
	@PostMapping("/refresh")
	public RefreshResponse refresh(@RequestBody RefreshRequest request) {
		String accessToken = authService.refresh(request.getRefreshToken());
		return new RefreshResponse(accessToken);
	}

}
