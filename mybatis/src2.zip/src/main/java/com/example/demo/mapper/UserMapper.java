/**
 * 2追加
 */
package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.entity.User;

@Mapper
public interface UserMapper {
    List<User> findAll();
    User findById(Long id);
    User findByEmail(String email);
    void insert(User user);
    void update(User user);
    void delete(Long id);
}
