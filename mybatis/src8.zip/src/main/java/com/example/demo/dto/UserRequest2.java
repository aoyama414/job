/**
 * 
 */
package com.example.demo.dto;

import lombok.Data;
@Data
public class UserRequest2 {
    private String name;
    private String email; 
    private String password;
    private String role;
}