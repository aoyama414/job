/**
 * 9 検索API
 */
package com.example.demo.dto;

import lombok.Data;

@Data
public class UserSearchRequest {
	private String name;
	private String email;
	private Integer page = 1;
	private Integer size = 10;
	private String sort = "id,asc";
	// 9で追加
	private Integer offset = 10;
}