/**
 * 10 RefreshToken
 */
package com.example.demo.entity;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class RefreshToken {
    private Long id;
    private Long userId;
    private String token;
    private LocalDateTime expiryDate;
}
