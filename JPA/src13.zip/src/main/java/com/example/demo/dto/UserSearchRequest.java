/**
 * 6
 */
package com.example.demo.dto;

import lombok.Data;

@Data
public class UserSearchRequest {
    private String name;
    private String email;
}