/**
 * 
 */
package com.example.demo.entity;

import java.util.List;

import lombok.Data;

/**
 * 11で削除
 */
//public enum Role {
//	USER, 
//	ADMIN
//}
/**
 * 11で追加
 */
@Data
public class Role {
    private Long id;
    private String name;
    private List<Permission> permissions;
}

