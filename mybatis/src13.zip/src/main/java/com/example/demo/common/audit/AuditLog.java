/**
 * 13追加
 */
package com.example.demo.common.audit;

import lombok.Data;

@Data
public class AuditLog {
    private Long id;
    private Long userId;
    private String action;
    private String method;
    private String path;
    private String requestBody;
    private Integer status;
    private String ipAddress;
}