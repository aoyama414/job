/**
 * 12
 */
package com.example.demo.security;

import java.io.IOException;
import java.time.LocalDateTime;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.demo.entity.AuditLog;
import com.example.demo.repository.AuditLogRepository;

@Component
public class AuditFilter extends OncePerRequestFilter {

    private final AuditLogRepository repo;

    public AuditFilter(AuditLogRepository repo) {
        this.repo = repo;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain)
            throws ServletException, IOException {

        long start = System.currentTimeMillis();

        try {
            chain.doFilter(request, response);

        } finally {
            try {
                String user = "anonymous";

                var auth = SecurityContextHolder.getContext().getAuthentication();
                if (auth != null && auth.isAuthenticated()) {
                    user = auth.getName();
                }

                AuditLog log = new AuditLog();
                log.setUsername(user); // ★ここ修正
                log.setMethod(request.getMethod());
                log.setPath(request.getRequestURI());
                log.setStatus(response.getStatus());
                log.setIp(request.getRemoteAddr());
                log.setTimestamp(LocalDateTime.now());

                long duration = System.currentTimeMillis() - start;
                log.setDuration(duration);

                repo.save(log);

            } catch (Exception e) {
                System.err.println("Audit log save failed: " + e.getMessage());
            }
        }
    }
}