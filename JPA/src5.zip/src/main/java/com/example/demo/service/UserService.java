/**
 * 4
 */
package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.demo.common.exception.BadRequestException;
import com.example.demo.common.exception.NotFoundException;
import com.example.demo.dto.PageResponse;
import com.example.demo.dto.UserRequest;
import com.example.demo.dto.UserResponse;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {

	private final UserRepository repo;

	public UserService(UserRepository repo) {
		this.repo = repo;
	}

	public List<UserResponse> findAll() {
		return repo.findAll()
				.stream()
				.map(UserResponse::from)
				.collect(Collectors.toList());
	}
	
	public PageResponse<UserResponse> findAll(Pageable pageable) {

	    Page<User> page = repo.findAll(pageable);

	    List<UserResponse> content = page.getContent().stream()
	            .map(user -> UserResponse.builder()
	                    .id(user.getId())
	                    .name(user.getName())
	                    .email(user.getEmail())
	                    .build())
	            .toList();

	    return PageResponse.<UserResponse>builder()
	            .content(content)
	            .page(page.getNumber())
	            .size(page.getSize())
	            .totalElements(page.getTotalElements())
	            .totalPages(page.getTotalPages())
	            .build();
	}
	
	

	public UserResponse findById(Long id) {
		User user = repo.findById(id)
				.orElseThrow(() -> new NotFoundException("User not found. id=" + id));
		return UserResponse.from(user);
	}

	public UserResponse save(UserRequest dto) {
		// 例：簡単なバリデーション
		if (dto.getEmail() == null || dto.getEmail().isEmpty()) {
			throw new BadRequestException("Email must not be empty");
		}

		User user = dto.toEntity();
		return UserResponse.from(repo.save(user));
	}

	public UserResponse update(Long id, UserRequest dto) {
		User user = repo.findById(id)
				.orElseThrow(() -> new NotFoundException("User not found. id=" + id));

		// 更新時のバリデーション例
		if (dto.getEmail() == null || dto.getEmail().isEmpty()) {
			throw new BadRequestException("Email must not be empty");
		}

		dto.updateEntity(user);

		return UserResponse.from(repo.save(user));
	}

	public void delete(Long id) {
		// deleteは存在チェックを入れるのが安全
		if (!repo.existsById(id)) {
			throw new NotFoundException("User not found. id=" + id);
		}
		repo.deleteById(id);
	}
}

/**
 * 3
 */
//package com.example.demo.service;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//import org.springframework.stereotype.Service;
//
//import com.example.demo.dto.UserRequest;
//import com.example.demo.dto.UserResponse;
//import com.example.demo.entity.User;
//import com.example.demo.repository.UserRepository;
//
//@Service
//public class UserService {
//
//    private final UserRepository repo;
//
//    public UserService(UserRepository repo) {
//        this.repo = repo;
//    }
//
//    public List<UserResponse> findAll() {
//        return repo.findAll()
//                .stream()
//                .map(UserResponse::from)
//                .collect(Collectors.toList());
//    }
//
//    public UserResponse findById(Long id) {
//        User user = repo.findById(id)
//                .orElseThrow(() -> new RuntimeException("User not found"));
//        return UserResponse.from(user);
//    }
//
//    public UserResponse save(UserRequest dto) {
//        User user = dto.toEntity();
//        return UserResponse.from(repo.save(user));
//    }
//
//    public UserResponse update(Long id, UserRequest dto) {
//        User user = repo.findById(id)
//                .orElseThrow(() -> new RuntimeException("User not found"));
//
//        dto.updateEntity(user);
//
//        return UserResponse.from(repo.save(user));
//    }
//
//    public void delete(Long id) {
//        repo.deleteById(id);
//    }
//}

/**
 * 2
 */
//package com.example.demo.service;
//
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//import com.example.demo.entity.User;
//import com.example.demo.repository.UserRepository;

//@Service
//public class UserService {
//    private final UserRepository repo;
//    public UserService(UserRepository repo) {
//        this.repo = repo;
//    }
//    
//    
//    
//    public List<User> findAll() {
//        return repo.findAll();
//    }
//    public User findById(Long id) {
//        return repo.findById(id)
//                .orElseThrow(() -> new RuntimeException("User not found"));
//    }
//    public User save(User user) {
//        return repo.save(user);
//    }
//    public void delete(Long id) {
//        repo.deleteById(id);
//    }
//}
