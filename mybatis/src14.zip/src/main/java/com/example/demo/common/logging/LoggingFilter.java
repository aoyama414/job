/**14追加
 */
package com.example.demo.common.logging;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class LoggingFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {
        long start = System.currentTimeMillis();
        log.info("REQUEST {} {}", request.getMethod(), request.getRequestURI());
        filterChain.doFilter(request, response);
        long time = System.currentTimeMillis() - start;
        log.info("RESPONSE {} {} status={} time={}ms",
                request.getMethod(),
                request.getRequestURI(),
                response.getStatus(),
                time);
    }
}