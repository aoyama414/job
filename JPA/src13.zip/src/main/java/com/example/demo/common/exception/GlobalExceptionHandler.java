/**
 * 4
 */
package com.example.demo.common.exception;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.dto.ErrorResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {

	// 400（バリデーション）
	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorResponse handleValidation(
			MethodArgumentNotValidException ex,
			HttpServletRequest request) {

		List<String> message = ex.getBindingResult()
				.getFieldErrors()
				.stream()
				.map(e -> e.getField() + ": " + e.getDefaultMessage())
				.toList(); // ここを修正

		//				.getFieldErrors()
		//				.stream()
		//				.map(e -> e.getField() + ": " + e.getDefaultMessage())
		//				.findFirst()
		//				.orElse("Validation error");

		return ErrorResponse.builder()
				.timestamp(LocalDateTime.now())
				.status(400)
				.error("VALIDATION_ERROR")
				.messages(message) //ここを修正
				.path(request.getRequestURI())
				.build();

	}
	
	/**
	 * 7
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(ResponseStatusException.class)
	public ErrorResponse handleResponseStatus(
	        ResponseStatusException ex,
	        HttpServletRequest request) {

	    return ErrorResponse.builder()
	            .timestamp(LocalDateTime.now())
	            .status(ex.getStatusCode().value())
	            .error(ex.getStatusCode().toString())
	            .messages(List.of(ex.getReason()))
	            .path(request.getRequestURI())
	            .build();
	}

	// 404
	@ExceptionHandler(NotFoundException.class)
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse handleNotFound(
			NotFoundException ex,
			HttpServletRequest request) {
		return ErrorResponse.builder()
				.timestamp(LocalDateTime.now())
				.status(404)
				.error("NOT_FOUND")
				.messages(List.of(ex.getMessage())) // ← ここを修正
				.path(request.getRequestURI())
				.build();
	}

	// 400
	@ExceptionHandler(BadRequestException.class)
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorResponse handleBadRequest(
			BadRequestException ex,
			HttpServletRequest request) {
		return ErrorResponse.builder()
				.timestamp(LocalDateTime.now())
				.status(400)
				.error("BAD_REQUEST")
				.messages(List.of(ex.getMessage())) // ← ここを修正
				.path(request.getRequestURI())
				.build();
	}
	
	/**
	 * 5
	 * @param ex
	 * @param request
	 * @return
	 */
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	@ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
	public ErrorResponse handleMethodNotSupported(
	        HttpRequestMethodNotSupportedException ex,
	        HttpServletRequest request) {

	    return ErrorResponse.builder()
	            .timestamp(LocalDateTime.now())
	            .status(405)
	            .error("METHOD_NOT_ALLOWED")
	            .messages(List.of("このHTTPメソッドはサポートされていません"))
	            .path(request.getRequestURI())
	            .build();
	}
	
	/**
	 * 5
	 * @param ex
	 * @param request
	 * @return
	 */
	
	@ExceptionHandler(Exception.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public ErrorResponse handleException(
	        Exception ex,
	        HttpServletRequest request) {

	    // ログには出す
	    ex.printStackTrace();

	    return ErrorResponse.builder()
	            .timestamp(LocalDateTime.now())
	            .status(500)
	            .error("INTERNAL_SERVER_ERROR")
	            .messages(List.of("予期しないエラーが発生しました")) // ← 固定にする
	            .path(request.getRequestURI())
	            .build();
	}
	
// 5
//	// 500（最後の砦）
//	@ExceptionHandler(Exception.class)
//	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
//	public ErrorResponse handleException(
//			Exception ex,
//			HttpServletRequest request) {
//		return ErrorResponse.builder()
//				.timestamp(LocalDateTime.now())
//				.status(500)
//				.error("INTERNAL_SERVER_ERROR")
//				.messages(List.of(ex.getMessage())) // ← ここを修正
//				.path(request.getRequestURI())
//				.build();
//	}
}