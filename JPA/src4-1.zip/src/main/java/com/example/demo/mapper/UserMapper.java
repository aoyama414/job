/**
 * 3
 */
package com.example.demo.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.example.demo.dto.UserRequest;
import com.example.demo.dto.UserResponse;
import com.example.demo.entity.User;

@Mapper(componentModel = "spring")
public interface UserMapper {

	// Request → Entity
	User toEntity(UserRequest dto);

	// Entity → Response
	UserResponse toResponse(User user);

	// List変換
	List<UserResponse> toResponseList(List<User> users);
}

 
