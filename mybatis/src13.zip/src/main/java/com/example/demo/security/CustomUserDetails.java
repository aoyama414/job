/**
 * 
 */
package com.example.demo.security;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.demo.entity.Role;
import com.example.demo.entity.User;

public class CustomUserDetails implements UserDetails {

	private final User user;
	private final List<GrantedAuthority> authorities; //11で追加

	public CustomUserDetails(User user, List<Role> roles) {
		// public CustomUserDetails(User user) { 11で削除
		//this.user = user; 

		this.user = user;
		// ROLE + PERMISSION を両方付与
		this.authorities = roles.stream()
				.flatMap(role -> {
					List<GrantedAuthority> auths = new ArrayList<>();
					// ROLE
					auths.add(new SimpleGrantedAuthority("ROLE_" + role.getName()));
					// PERMISSION
					role.getPermissions().forEach(p -> auths.add(new SimpleGrantedAuthority(p.getName())));
					return auths.stream();
				})
				.toList();
	}

	/**
	 * 11で追加
	 */
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}

	/**
	 * 11で削除
	 */
	//	@Override
	//	public List<GrantedAuthority> getAuthorities() {
	//		return List.of(
	//				new SimpleGrantedAuthority("ROLE_" + user.getRole()));
	//	}
	
	/**
	 * 13追加
	 * @return
	 */
	public Long getUserId() {
		return user.getId();
	}

	@Override
	public String getPassword() {
		return user.getPassword();
	}

	@Override
	public String getUsername() {
		return user.getEmail();
	}

	public String getRole() {
		return user.getRole();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

}
