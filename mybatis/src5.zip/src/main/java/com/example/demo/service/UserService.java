/**
 * 2追加
 */
package com.example.demo.service;

import java.util.List;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.example.demo.common.exception.ApiException;
import com.example.demo.common.exception.ErrorCode;
import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
	private final UserMapper userMapper;

	public List<User> findAll() {
		return userMapper.findAll();
	}

	public User findById(Long id) {
		return userMapper.findById(id);
	}

	public User create(User user) {
		// 5削除
		//		try {
		//			userMapper.insert(user);
		//			return user;
		//		} catch (DataIntegrityViolationException e) {
		//			throw new RuntimeException("Email already exists");
		//		}

		// 5で追加
		try {
			userMapper.insert(user);
			return user;
		} catch (DataIntegrityViolationException e) {
			throw new ApiException(ErrorCode.EMAIL_ALREADY_EXISTS);
		}

	}

	public User update(User user) {
		userMapper.update(user);
		return user;
	}

	public void delete(Long id) {
		userMapper.delete(id);
	}
}