/**
 * 5追加
 */
package com.example.demo.common.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(ApiException.class)
	public ResponseEntity<ErrorResponse> handleApiException(ApiException ex) {
		ErrorCode errorCode = ex.getErrorCode();
		return ResponseEntity
				.status(errorCode.getStatus())
				.body(new ErrorResponse(
						errorCode.getCode(),
						ex.getMessage()));
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorResponse> handleException(Exception ex) {
		return ResponseEntity
				.status(ErrorCode.INTERNAL_SERVER_ERROR.getStatus())
				.body(new ErrorResponse(
						ErrorCode.INTERNAL_SERVER_ERROR.getCode(),
						ex.getMessage()));
	}
}
