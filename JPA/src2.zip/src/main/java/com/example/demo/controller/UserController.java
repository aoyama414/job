/**
 * 2
 */
package com.example.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	private final UserService service;

	public UserController(UserService service) {
		this.service = service;
	}

	// 一覧取得
	@GetMapping
	public List<User> getAll() {
		return service.findAll();
	}

	// 1件取得
	@GetMapping("/{id}")
	public User getById(@PathVariable Long id) {
		return service.findById(id);
	}

	// 登録
	@PostMapping
	public User create(@RequestBody User user) {
		return service.save(user);
	}

	// 更新
	@PutMapping("/{id}")
	public User update(@PathVariable Long id, @RequestBody User user) {
		user.setId(id);
		return service.save(user);
	}

	// 削除
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Long id) {
		service.delete(id);
	}
}