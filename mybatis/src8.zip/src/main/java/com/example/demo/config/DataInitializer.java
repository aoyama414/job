/**
 * 
 */
package com.example.demo.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class DataInitializer {

    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;

    @Bean
    CommandLineRunner init() {
        return args -> {

            int count = userMapper.count();

            if (count == 0) {
                User user = new User();
                user.setName("admin");
                user.setEmail("admin@test.com");
                user.setPassword(passwordEncoder.encode("admin123"));

                userMapper.insert(user);

                System.out.println("初期ユーザーを作成しました：admin / admin123");
            }
        };
    }
}