/**
 * この ApiError クラスは、APIのエラーレスポンスを統一フォーマットで返すためのDTOです。
   主に @RestControllerAdvice（グローバル例外ハンドラ）と組み合わせて使います。
 */
package com.example.demo.common.exception;

import java.util.List;

import lombok.Builder;
import lombok.Data;
@Data
@Builder
public class ApiError {
    private String code;
    private String message;
    private List<FieldErrorDetail> errors;
}
