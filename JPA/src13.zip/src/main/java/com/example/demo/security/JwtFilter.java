/**
 * 
 */
package com.example.demo.security;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {

	private final JwtUtil jwtUtil;
	private final CustomUserDetailsService userDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request,
			HttpServletResponse response,
			FilterChain filterChain)
			throws ServletException, IOException {

		// ★ ログインAPIはスキップ
		if (request.getRequestURI().startsWith("/auth")) {
			filterChain.doFilter(request, response);
			return;
		}

		String header = request.getHeader("Authorization");

		if (header != null && header.startsWith("Bearer ")) {
			String token = header.substring(7);

			try {
				// ★ トークン解析
				Claims claims = jwtUtil.parseToken(token);
				String email = claims.getSubject();

				// ★ DBからユーザー取得
				CustomUserDetails userDetails = (CustomUserDetails) userDetailsService.loadUserByUsername(email);

				// ★ 認証オブジェクト作成
				UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
						userDetails,
						null,
						userDetails.getAuthorities());

				// ★ SecurityContextに設定
				if (SecurityContextHolder.getContext().getAuthentication() == null) {
					SecurityContextHolder.getContext().setAuthentication(auth);
				}

			} catch (io.jsonwebtoken.JwtException e) {
				// ★ トークン不正 → 401
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				return;
			}
		}

		// ★ 次のフィルタへ
		filterChain.doFilter(request, response);
	}
}
