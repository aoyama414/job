/**
 * 
 */
package com.example.demo.security;

import java.util.Date;
import java.util.UUID;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {
	private final String SECRET = "9xT!kL2@pQ8#sV4$wX7^yZ1&bC6*D8eGhJmN0oPqRrStUvWxYz123456";

	public String generateToken(String email) {
		return Jwts.builder()
				.setSubject(email)
				.setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + 86400000))
				.signWith(Keys.hmacShaKeyFor(SECRET.getBytes()))
				.compact();
	}

	public String extractEmail(String token) {
		return Jwts.parserBuilder()
				.setSigningKey(SECRET.getBytes())
				.build()
				.parseClaimsJws(token)
				.getBody()
				.getSubject();
	}

	public String generateToken(String email, String role) {
		return Jwts.builder()
				.setSubject(email)
				.claim("role", role)
				.setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + 86400000)) //10削除
				.signWith(Keys.hmacShaKeyFor(SECRET.getBytes()))
				.compact();
	}

	public String extractRole(String token) {
		return Jwts.parserBuilder()
				.setSigningKey(SECRET.getBytes())
				.build()
				.parseClaimsJws(token)
				.getBody()
				.get("role", String.class);

	}

	/**
	 * 10 追加
	 * @param email
	 * @param role
	 * @return
	 */
	public String generateAccessToken(String email, String role) {
		return Jwts.builder()
				.setSubject(email)
				.claim("role", role)
				.setExpiration(new Date(System.currentTimeMillis() + 15 * 60 * 1000)) // 15分
				.signWith(Keys.hmacShaKeyFor(SECRET.getBytes()))
				.compact();
	}

	/**
	 * 10 追加
	 * @return　UUID
	 */
	public String generateRefreshToken() {
		return UUID.randomUUID().toString();
	}

}
