/**
 * 13追加
 */
package com.example.demo.common.audit;


import jakarta.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.example.demo.security.CustomUserDetails;

import lombok.RequiredArgsConstructor;

@Aspect
@Component
@RequiredArgsConstructor
public class AuditAspect {
    private final AuditService auditService;
    @Around("@annotation(audit)")
    public Object log(ProceedingJoinPoint joinPoint, Audit audit) throws Throwable {
        HttpServletRequest request =
            ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
            .getRequest();
        Long userId = null;
        // SecurityContextから取得
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getPrincipal() instanceof CustomUserDetails user) {
            userId = user.getUserId();
        }
        Object result;
        int status = 200;
        try {
            result = joinPoint.proceed();
        } catch (Exception e) {
            status = 500;
            throw e;
        } finally {
            AuditLog log = new AuditLog();
            log.setUserId(userId);
            log.setAction(audit.value());
            log.setMethod(request.getMethod());
            log.setPath(request.getRequestURI());
            log.setIpAddress(request.getRemoteAddr());
            log.setStatus(status);
            auditService.save(log);
        }
        return result;
    }
}
