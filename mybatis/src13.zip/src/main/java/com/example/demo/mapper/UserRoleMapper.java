/**
 * 11で追加
 */
package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.entity.Role;

@Mapper
public interface UserRoleMapper {
    List<Role> findRolesByUserId(Long userId);
}