/**
 * 3
 */
package com.example.demo.dto;

import com.example.demo.entity.User;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserResponse {
    private Long id;
    private String name;
    private String email;

//    // Entity → DTO
//    public static UserResponse from(User user) {
//        UserResponse dto = new UserResponse();
//        dto.setId(user.getId());
//        dto.setName(user.getName());
//        dto.setEmail(user.getEmail());
//        return dto;
//    }
        
    // 5★これを追加
    public static UserResponse from(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .build();
    }
}