/**
 * 2
 * SQL書かなくてOK（JPAの強み）
 */
package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.example.demo.entity.User;

public interface UserRepository extends
		JpaRepository<User, Long>,
		JpaSpecificationExecutor<User> {
	Optional<User> findByEmail(String email);	// ここを追加
}

//public interface UserRepository extends JpaRepository<User, Long> {
//
//}
