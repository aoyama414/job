variable "aws_region" {
  default = "ap-northeast-1"
}

variable "project_name" {
  default = "sample"
}

variable "vpc_cidr" {
  default = "10.0.0.0/16"
}
