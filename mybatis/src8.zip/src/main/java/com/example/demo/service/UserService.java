/**
 * 
 */
package com.example.demo.service;

import java.util.List;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.example.demo.common.exception.ApiException;
import com.example.demo.common.exception.ErrorCode;
import com.example.demo.dto.PageResponse; // 8で追加
import com.example.demo.entity.User;
import com.example.demo.mapper.UserMapper;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
	private final UserMapper userMapper;

	public List<User> findAll() {
		return userMapper.findAll();
	}

	//	public User findById(Long id) {
	//		return userMapper.findById(id);
	//	}

	public User findById(Long id) {
		User user = userMapper.findById(id);
		if (user == null) {
			throw new ApiException(ErrorCode.USER_NOT_FOUND);
		}
		return user;
	}

	//	public User create(User user) {
	//	    try {
	//	        userMapper.insert(user);
	//	        return user;
	//	    } catch (DataIntegrityViolationException e) {
	//	        throw new ApiException(ErrorCode.EMAIL_ALREADY_EXISTS);
	//	    }
	//	}

	public User create(User user) {
		try {
			userMapper.insert(user);
			return user;
		} catch (DataIntegrityViolationException e) {
			throw new ApiException(ErrorCode.EMAIL_ALREADY_EXISTS);
		}
	}

	//	public User update(User user) {
	//		userMapper.update(user);
	//		return user;
	//	}

	//	public User update(User user) {
	//
	//	    User existing = userMapper.findById(user.getId());
	//	    if (existing == null) {
	//	        throw new ApiException(ErrorCode.USER_NOT_FOUND);
	//	    }
	//
	//	    userMapper.update(user);
	//	    return user;
	//	}

	public User update(User user) {

		int updatedCount = userMapper.update(user);

		if (updatedCount == 0) {
			throw new ApiException(ErrorCode.USER_NOT_FOUND);
		}

		return user;
	}

	//	public void delete(Long id) {
	//		userMapper.delete(id);
	//	}

	public void delete(Long id) {

		int deletedCount = userMapper.delete(id);

		if (deletedCount == 0) {
			throw new ApiException(ErrorCode.USER_NOT_FOUND);
		}
	}

	/**
	 * 8　ページングAPI
	 * @param page
	 * @param size
	 * @return
	 */
	
	public PageResponse<User> findPage(int page, int size) {

		// ★ ガード
		if (page < 1) {
			page = 1;
		}
		if (size <= 0) {
			size = 10;
		}

		long total = userMapper.count();

		int totalPages = (int) Math.ceil((double) total / size);

		// ★ データ0件対策（好みで調整）
		if (totalPages == 0) {
			totalPages = 1;
		}

		// ★ pageが超えていたら補正
		if (page > totalPages) {
			page = totalPages;
		}

		int offset = (page - 1) * size;

		List<User> users = userMapper.findPage(offset, size);

		return PageResponse.<User> builder()
				.content(users)
				.page(page)
				.size(size)
				.totalElements(total)
				.totalPages(totalPages)
				.build();
	}

}