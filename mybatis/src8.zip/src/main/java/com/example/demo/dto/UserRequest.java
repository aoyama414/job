/**
 * 
 */
package com.example.demo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

import lombok.Data;
@Data
public class UserRequest {
    @NotBlank(message = "名前は必須です")
    private String name;
    @Email(message = "メール形式が不正です")
    @NotBlank(message = "メールは必須です")
    private String email;
    @NotBlank(message = "パスワードは必須です")    
    private String password;
    private String role;
}