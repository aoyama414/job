/**
 * 10 RefreshToken
 */
package com.example.demo.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.demo.entity.RefreshToken;

@Mapper
public interface RefreshTokenMapper {
	void insert(RefreshToken token);

	RefreshToken findByToken(@Param("token") String token);

	void deleteByUserId(@Param("userId") Long userId);
}