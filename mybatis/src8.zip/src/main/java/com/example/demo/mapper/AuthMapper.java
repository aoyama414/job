/**
 * 
 */
package com.example.demo.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.entity.User;

@Mapper
public interface AuthMapper {
    User findByEmail(String email);
}
