/**
 * 7で追加
 */
package com.example.demo.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.LoginRequest;
import com.example.demo.service.AuthService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthService authService;
    @PostMapping("/login")
    public Map<String, String>  login(@RequestBody LoginRequest request) {
    	return authService.login(request);   	

    }
    
    @PostMapping("/refresh")
    public String refresh(@RequestBody Map<String, String> req) {
        return authService.refresh(req.get("refreshToken"));
    }
}
