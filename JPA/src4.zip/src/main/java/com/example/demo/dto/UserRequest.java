/**
 * 3
 */
package com.example.demo.dto;

import com.example.demo.entity.User;

import lombok.Data;

@Data
public class UserRequest {
    private String name;
    private String email;

    // DTO → Entity
    public User toEntity() {
        User user = new User();
        user.setName(this.name);
        user.setEmail(this.email);
        return user;
    }

    // 既存Entity更新用
    public void updateEntity(User user) {
        user.setName(this.name);
        user.setEmail(this.email);
    }
}
