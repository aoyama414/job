package com.example.demo.entity;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class User {
	private Long id;
	private String name;
	private String email;
	private String password;
	private LocalDateTime created_at;
}
