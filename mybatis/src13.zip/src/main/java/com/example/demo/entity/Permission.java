/**
 * 11 追加
 */
package com.example.demo.entity;

import lombok.Data;

@Data
public class Permission {
    private Long id;
    private String name;
}