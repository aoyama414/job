/**
 * このクラスは、バリデーションエラーの詳細を1件ずつ表現するためのDTO（データ転送オブジェクト）です。
   主に「どの項目で」「どんなエラーが起きたか」をフロントに返す用途で使います。
 */
package com.example.demo.common.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
public class FieldErrorDetail {
    private String field;
    private String message;
}
