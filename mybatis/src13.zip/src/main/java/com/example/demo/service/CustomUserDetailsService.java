/**
 * 
 */
package com.example.demo.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Role;
import com.example.demo.entity.User;
import com.example.demo.mapper.AuthMapper;
import com.example.demo.mapper.RolePermissionMapper;
import com.example.demo.mapper.UserRoleMapper;
import com.example.demo.security.CustomUserDetails;

import lombok.RequiredArgsConstructor;

/**
 * 11で削除
 */
//@Service
//@RequiredArgsConstructor
//public class CustomUserDetailsService implements UserDetailsService {
//	private final AuthMapper authMapper;
//
//	@Override
//	public UserDetails loadUserByUsername(String email) {
//		User user = authMapper.findByEmail(email);
//		if (user == null) {
//			throw new UsernameNotFoundException("User not found");
//		}
//		return new CustomUserDetails(user);
//	}
//}


@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {
    private final AuthMapper authMapper;
    private final UserRoleMapper userRoleMapper;
    private final RolePermissionMapper rolePermissionMapper;
    @Override
    public UserDetails loadUserByUsername(String email) {
        User user = authMapper.findByEmail(email);
        List<Role> roles = userRoleMapper.findRolesByUserId(user.getId());
        // 各ロールに権限を詰める
        for (Role role : roles) {
            role.setPermissions(
                rolePermissionMapper.findByRoleId(role.getId())
            );
        }
        return new CustomUserDetails(user, roles);
    }
}