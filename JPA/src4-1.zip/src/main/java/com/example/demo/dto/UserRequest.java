/**
 * 3
 */
package com.example.demo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import com.example.demo.entity.User;

import lombok.Data;

@Data
public class UserRequest {
	// 3-1 バリデーションの追加
    @NotBlank(message = "名前は必須です")
    @Size(max = 100, message = "名前は100文字以内")
    private String name;

    @NotBlank(message = "メールは必須です")
    @Email(message = "メール形式が不正です")
    private String email;

    // DTO → Entity
    public User toEntity() {
        User user = new User();
        user.setName(this.name);
        user.setEmail(this.email);
        return user;
    }

    // 既存Entity更新用
    public void updateEntity(User user) {
        user.setName(this.name);
        user.setEmail(this.email);
    }
}
