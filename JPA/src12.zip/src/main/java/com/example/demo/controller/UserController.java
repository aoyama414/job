/**
 * 3
 */
package com.example.demo.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.aspect.Audit;
import com.example.demo.dto.PageResponse;
import com.example.demo.dto.UserRequest;
import com.example.demo.dto.UserRequest2;
import com.example.demo.dto.UserResponse;
import com.example.demo.dto.UserSearchRequest;
import com.example.demo.service.UserService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserController {
	private final UserService service;

	@Audit("READ_ALLUSER")
	public List<UserResponse> getAll() {
		return service.findAll();
	}

	@GetMapping("/{id}")
	@Audit("READ_USER")
	public UserResponse getById(@PathVariable Long id) {
		return service.findById(id);
	}

	@PostMapping
	@Audit("CREATE_USER")
	public UserResponse create(@Valid @RequestBody UserRequest dto) {

		return service.save(dto);
	}

	@PutMapping("/{id}")
	@Audit("UPDATE_USER")
	public UserResponse update(@Valid @PathVariable Long id, @RequestBody UserRequest2 dto) {

		return service.update(id, dto);
	}

	@DeleteMapping("/{id}")
	@Audit("UPDATE_USER")
	public void delete(@PathVariable Long id) {
		service.delete(id);
	}

	/**
	 * 5
	 * @param pageable
	 * @return
	 */
	@GetMapping
	@Audit("GET_USERS_PAGE")
	public PageResponse<UserResponse> getAll(
			@PageableDefault(size = 10, sort = "id") Pageable pageable) {
		return service.findAll(pageable);
	}

	@GetMapping("/search")
	@Audit("SEARCH_USERS")
	public PageResponse<UserResponse> search(
			UserSearchRequest req,
			Pageable pageable) {
		return service.search(req, pageable);
	}

}