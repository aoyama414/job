/**
 * 14追加
 */
package com.example.demo.common.logging;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Slf4j
public class LogUtil {
    public static void info(String message, Object... args) {
        log.info(message, args);
    }
    public static void warn(String message, Object... args) {
        log.warn(message, args);
    }
    public static void error(String message, Throwable e) {
        log.error(message, e);
    }
}
