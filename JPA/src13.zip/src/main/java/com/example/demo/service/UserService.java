package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.common.exception.BadRequestException;
import com.example.demo.common.exception.NotFoundException;
import com.example.demo.dto.PageResponse;
import com.example.demo.dto.UserRequest;
import com.example.demo.dto.UserRequest2;
import com.example.demo.dto.UserResponse;
import com.example.demo.dto.UserSearchRequest;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.specification.UserSpecification;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository repo;
    private final PasswordEncoder passwordEncoder;

    public List<UserResponse> findAll() {
        log.info("全件取得開始");

        List<UserResponse> result = repo.findAll()
                .stream()
                .map(UserResponse::from)
                .collect(Collectors.toList());

        log.info("全件取得完了 件数={}", result.size());
        return result;
    }

    public PageResponse<UserResponse> findAll(Pageable pageable) {
        log.info("ページング取得開始 page={}, size={}", pageable.getPageNumber(), pageable.getPageSize());

        Page<User> page = repo.findAll(pageable);

        List<UserResponse> content = page.getContent().stream()
                .map(user -> UserResponse.builder()
                        .id(user.getId())
                        .name(user.getName())
                        .email(user.getEmail())
                        .build())
                .toList();

        log.info("ページング取得完了 件数={}, total={}", content.size(), page.getTotalElements());

        return PageResponse.<UserResponse>builder()
                .content(content)
                .page(page.getNumber())
                .size(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .build();
    }

    public UserResponse findById(Long id) {
        log.info("ID検索開始 id={}", id);

        User user = repo.findById(id)
                .orElseThrow(() -> {
                    log.warn("ユーザー未存在 id={}", id);
                    return new NotFoundException("User not found. id=" + id);
                });

        log.info("ID検索成功 id={}", id);
        return UserResponse.from(user);
    }

    public UserResponse save(UserRequest dto) {
        log.info("ユーザー登録開始 email={}", dto.getEmail());

        if (dto.getEmail() == null || dto.getEmail().isEmpty()) {
            log.warn("バリデーションエラー emailが空");
            throw new BadRequestException("Email must not be empty");
        }

        User user = dto.toEntity();
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        User saved = repo.save(user);

        log.info("ユーザー登録成功 id={}", saved.getId());

        return UserResponse.from(saved);
    }

    public UserResponse update(Long id, UserRequest2 dto) {
        log.info("ユーザー更新開始 id={}", id);

        User user = repo.findById(id)
                .orElseThrow(() -> {
                    log.warn("更新対象なし id={}", id);
                    return new NotFoundException("User not found. id=" + id);
                });

        if (dto.getEmail() == null || dto.getEmail().isEmpty()) {
            log.warn("更新バリデーションエラー id={}", id);
            throw new BadRequestException("Email must not be empty");
        }

        dto.updateEntity(user);
        User updated = repo.save(user);

        log.info("ユーザー更新成功 id={}", id);

        return UserResponse.from(updated);
    }

    public void delete(Long id) {
        log.info("ユーザー削除開始 id={}", id);

        if (!repo.existsById(id)) {
            log.warn("削除対象なし id={}", id);
            throw new NotFoundException("User not found. id=" + id);
        }

        repo.deleteById(id);

        log.info("ユーザー削除成功 id={}", id);
    }

    public PageResponse<UserResponse> search(
            UserSearchRequest req,
            Pageable pageable) {

        log.info("ユーザー検索開始 page={}, size={}", pageable.getPageNumber(), pageable.getPageSize());
        log.debug("検索条件 name={}, email={}", req.getName(), req.getEmail());

        Page<User> page = repo.findAll(
                UserSpecification.search(req),
                pageable);

        List<UserResponse> content = page.getContent().stream()
                .map(user -> UserResponse.builder()
                        .id(user.getId())
                        .name(user.getName())
                        .email(user.getEmail())
                        .build())
                .toList();

        log.info("ユーザー検索完了 件数={}, total={}", content.size(), page.getTotalElements());

        return PageResponse.<UserResponse>builder()
                .content(content)
                .page(page.getNumber())
                .size(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .build();
    }
}