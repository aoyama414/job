/**
 * 
 */
package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.example.demo.security.JwtFilter;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {
	private final JwtFilter jwtFilter;

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		return http
				.csrf(csrf -> csrf.disable())
				//                .authorizeHttpRequests(auth -> auth
				//                        .requestMatchers("/auth/**").permitAll()
				//                        .anyRequest().authenticated()
				//                )
				//                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
				//                .build();
				.authorizeHttpRequests(auth -> auth
						.requestMatchers("/auth/**").permitAll()
						// 管理者のみ
						.requestMatchers("/admin/**").hasRole("ADMIN")
						// ユーザー以上
						.requestMatchers("/users/**").hasAnyRole("USER", "ADMIN")
						.anyRequest().authenticated())
				.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
				.build();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
