/**
 * 
 */
package com.example.demo.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.common.exception.ApiException;
import com.example.demo.common.exception.ErrorCode;
import com.example.demo.entity.User;
import com.example.demo.mapper.AuthMapper;
import com.example.demo.security.JwtUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthService {
	private final AuthMapper authMapper;
	private final PasswordEncoder passwordEncoder;
	private final JwtUtil jwtUtil;

	//	public String login(String email, String password) {
	//		User user = authMapper.findByEmail(email);
	//		if (user == null) {
	//			throw new ApiException(ErrorCode.USER_NOT_FOUND);
	//		}
	//		if (!passwordEncoder.matches(password, user.getPassword())) {
	//			throw new ApiException(ErrorCode.INVALID_CREDENTIALS);
	//		}
	//		return jwtUtil.generateToken(email);
	//	}

	public String login(String email, String password) {

		User user = authMapper.findByEmail(email);

		// ユーザー存在チェック＋パスワードチェックをまとめる
		if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
			throw new ApiException(ErrorCode.INVALID_CREDENTIALS);
		}

		return jwtUtil.generateToken(email);

	}

}