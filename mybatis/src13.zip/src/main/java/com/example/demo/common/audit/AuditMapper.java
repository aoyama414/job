/**
 * 13追加
 */
package com.example.demo.common.audit;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AuditMapper {
    void insert(AuditLog log);
}
