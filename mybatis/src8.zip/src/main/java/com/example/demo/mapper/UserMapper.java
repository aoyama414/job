/**
 * 
 */
package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.entity.User;

@Mapper
public interface UserMapper {
	List<User> findAll();

	User findById(Long id);

	User findByEmail(String email);

	void insert(User user);

	int update(User user);

	int delete(Long id);

	int count();
	// 8で追加
	List<User> findPage(int offset, int limit);

}
