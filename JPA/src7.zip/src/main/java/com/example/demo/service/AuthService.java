/**
 * 7
 */
package com.example.demo.service;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.dto.LoginRequest;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.JwtUtil;

@Service
public class AuthService {
	private final UserRepository repo;
	private final PasswordEncoder encoder;
	private final JwtUtil jwtUtil;

	public AuthService(UserRepository repo,
			PasswordEncoder encoder,
			JwtUtil jwtUtil) {
		this.repo = repo;
		this.encoder = encoder;
		this.jwtUtil = jwtUtil;
	}

	public String login(LoginRequest req) {
	    User user = repo.findByEmail(req.getEmail())
	            .orElseThrow(() -> new ResponseStatusException(
	                    HttpStatus.UNAUTHORIZED,
	                    "メールとパスワード確認してください"
	            ));

	    if (!encoder.matches(req.getPassword(), user.getPassword())) {
	        throw new ResponseStatusException(
	                HttpStatus.UNAUTHORIZED,
	                "メールとパスワード確認してください"
	        );
	    }

	    return jwtUtil.generateToken(user.getEmail());
	}

}
