/**
 * 3
 */
package com.example.demo.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.demo.dto.UserRequest;
import com.example.demo.dto.UserResponse;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@Service
public class UserService {

    private final UserRepository repo;

    public UserService(UserRepository repo) {
        this.repo = repo;
    }

    public List<UserResponse> findAll() {
        return repo.findAll()
                .stream()
                .map(UserResponse::from)
                .collect(Collectors.toList());
    }

    public UserResponse findById(Long id) {
        User user = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return UserResponse.from(user);
    }

    public UserResponse save(UserRequest dto) {
        User user = dto.toEntity();
        return UserResponse.from(repo.save(user));
    }

    public UserResponse update(Long id, UserRequest dto) {
        User user = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        dto.updateEntity(user);

        return UserResponse.from(repo.save(user));
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}


/**
 * 2
 */
//package com.example.demo.service;
//
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//import com.example.demo.entity.User;
//import com.example.demo.repository.UserRepository;

//@Service
//public class UserService {
//    private final UserRepository repo;
//    public UserService(UserRepository repo) {
//        this.repo = repo;
//    }
//    
//    
//    
//    public List<User> findAll() {
//        return repo.findAll();
//    }
//    public User findById(Long id) {
//        return repo.findById(id)
//                .orElseThrow(() -> new RuntimeException("User not found"));
//    }
//    public User save(User user) {
//        return repo.save(user);
//    }
//    public void delete(Long id) {
//        repo.deleteById(id);
//    }
//}

