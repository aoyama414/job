/**
 * 3
 */
package com.example.demo.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.aspect.Audit;
import com.example.demo.dto.PageResponse;
import com.example.demo.dto.UserRequest;
import com.example.demo.dto.UserRequest2;
import com.example.demo.dto.UserResponse;
import com.example.demo.dto.UserSearchRequest;
import com.example.demo.service.UserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
@Slf4j  // ← これ追加
public class UserController {

    private final UserService service;

    @Audit("READ_ALLUSER")
    @GetMapping("/all")
    public List<UserResponse> getAll() {
        log.info("START getAll()");
        List<UserResponse> result = service.findAll();
        log.info("END getAll() count={}", result.size());
        return result;
    }

    @GetMapping("/{id}")
    @Audit("READ_USER")
    public UserResponse getById(@PathVariable Long id) {
        log.info("START getById id={}", id);
        try {
            UserResponse res = service.findById(id);
            log.info("END getById success id={}", id);
            return res;
        } catch (Exception e) {
            log.error("ERROR getById id={} message={}", id, e.getMessage(), e);
            throw e;
        }
    }

    @PostMapping
    @Audit("CREATE_USER")
    public UserResponse create(@Valid @RequestBody UserRequest dto) {
        log.info("START create email={}", dto.getEmail());

        UserResponse res = service.save(dto);

        log.info("END create id={}", res.getId());
        return res;
    }

    @PutMapping("/{id}")
    @Audit("UPDATE_USER")
    public UserResponse update(@PathVariable Long id,
                               @Valid @RequestBody UserRequest2 dto) {
        log.info("START update id={}", id);

        UserResponse res = service.update(id, dto);

        log.info("END update id={}", id);
        return res;
    }

    @DeleteMapping("/{id}")
    @Audit("DELETE_USER") // ← 修正（元はUPDATEになってた）
    public void delete(@PathVariable Long id) {
        log.info("START delete id={}", id);

        service.delete(id);

        log.info("END delete id={}", id);
    }

    @GetMapping
    @Audit("GET_USERS_PAGE")
    public PageResponse<UserResponse> getAll(
            @PageableDefault(size = 10, sort = "id") Pageable pageable) {

        log.info("START getAll(page) page={} size={}",
                pageable.getPageNumber(), pageable.getPageSize());

        PageResponse<UserResponse> res = service.findAll(pageable);

        log.info("END getAll(page) total={}", res.getTotalElements());
        return res;
    }

    @GetMapping("/search")
    @Audit("SEARCH_USERS")
    public PageResponse<UserResponse> search(
            UserSearchRequest req,
            Pageable pageable) {

        log.info("START search name={} page={}",
                req.getName(), pageable.getPageNumber());

        PageResponse<UserResponse> res = service.search(req, pageable);

        log.info("END search total={}", res.getTotalElements());
        return res;
    }
}