/**
 * 7
 */
package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.example.demo.dto.LoginRequest;
import com.example.demo.entity.RefreshToken;
import com.example.demo.entity.User;
import com.example.demo.repository.RefreshTokenRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.security.CustomUserDetails;
import com.example.demo.security.JwtUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthService {
	private final UserRepository repo;
	private final JwtUtil jwtUtil;
	private final RefreshTokenRepository refreshRepo;
	private final AuthenticationManager authManager;

	@Transactional
	public Map<String, String> login(LoginRequest req) {

		try {
			// ★ 認証（ここでUserDetailsServiceが呼ばれる）
			var authentication = authManager.authenticate(
					new UsernamePasswordAuthenticationToken(
							req.getEmail(),
							req.getPassword()));

			// ★ 認証成功後のユーザー取得
			CustomUserDetails user = (CustomUserDetails) authentication.getPrincipal();

			// ★ JWT生成（DBのroleを使用）
			String accessToken = jwtUtil.generateAccessToken(
					user.getUsername(),
					user.getUser().getRole().name());

			String refreshToken = jwtUtil.generateRefreshToken();

			// ★ RefreshToken保存
			RefreshToken token = new RefreshToken();
			token.setToken(refreshToken);
			token.setEmail(user.getUsername());
			token.setExpiryDate(LocalDateTime.now().plusDays(7));

			refreshRepo.deleteByEmail(user.getUsername());
			refreshRepo.save(token);

			return Map.of(
					"accessToken", accessToken,
					"refreshToken", refreshToken);

		} catch (Exception e) {
			// ★ 認証失敗
			throw new ResponseStatusException(
					HttpStatus.UNAUTHORIZED,
					"メールとパスワードを確認してください");
		}
	}

	/**
	 * 8で作成、9で修正
	 * @param refreshToken
	 * @return
	 */
	public String refresh(String refreshToken) {
		RefreshToken token = refreshRepo.findByToken(refreshToken)
				.orElseThrow(() -> new RuntimeException("Invalid refresh token"));


		if (token == null) {
			throw new RuntimeException("Token not found");
		}

		if (token.getExpiryDate().isBefore(LocalDateTime.now())) {
			throw new RuntimeException("Token expired");
		}

		User user = repo.findByEmail(token.getEmail())
				.orElseThrow(() -> new RuntimeException("User not found"));
		return jwtUtil.generateAccessToken(user.getEmail(), user.getRole().name());
	}

}
