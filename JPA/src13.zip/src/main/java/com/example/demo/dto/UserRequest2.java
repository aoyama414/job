/**
 * 7
 */
package com.example.demo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import com.example.demo.entity.Role;
import com.example.demo.entity.User;

import lombok.Data;

@Data
public class UserRequest2 {
	// 3-1 バリデーションの追加
    @NotBlank(message = "名前は必須です")
    @Size(max = 100, message = "名前は100文字以内")
    private String name;

    @NotBlank(message = "メールは必須です")
    @Email(message = "メール形式が不正です")
    private String email;
    
    // ★追加（任意）
    private Role role;

    // DTO → Entity
    public User toEntity() {
        User user = new User();
        user.setName(this.name);
        user.setEmail(this.email);
        // ★デフォルト or 指定
        user.setRole(this.role != null ? this.role : Role.USER);
        return user;
    }

    // 既存Entity更新用
    public void updateEntity(User user) {
        user.setName(this.name);
        user.setEmail(this.email);
        // ★ロールは「指定されたときだけ更新」
        if (this.role != null) {
            user.setRole(this.role);
        }
    }
}
