/**
 * 
 */
package com.example.demo.service;

import java.time.LocalDateTime;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.RefreshToken;
import com.example.demo.entity.User;
import com.example.demo.mapper.AuthMapper;
import com.example.demo.mapper.RefreshTokenMapper;
import com.example.demo.mapper.UserMapper;
import com.example.demo.security.JwtUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthService {
	private final AuthMapper authMapper;
	private final PasswordEncoder passwordEncoder;
	private final JwtUtil jwtUtil;
	// 10で追加
	@Autowired
	private RefreshTokenMapper refreshTokenMapper;
	@Autowired
	private UserMapper userMapper;

	//	public String login(String email, String password) {
	//		User user = authMapper.findByEmail(email);
	//		if (user == null) {
	//			throw new ApiException(ErrorCode.USER_NOT_FOUND);
	//		}
	//		if (!passwordEncoder.matches(password, user.getPassword())) {
	//			throw new ApiException(ErrorCode.INVALID_CREDENTIALS);
	//		}
	//		return jwtUtil.generateToken(email);
	//	}
	// 7で削除
	//	public String login(String email, String password) {
	//
	//		User user = authMapper.findByEmail(email);
	//
	//		// ユーザー存在チェック＋パスワードチェックをまとめる
	//		if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
	//			throw new ApiException(ErrorCode.INVALID_CREDENTIALS);
	//		}
	//
	//		return jwtUtil.generateToken(email);
	//
	//	}
	//  10で削除
	//	7で追加
	//	public String login(String email, String password) {
	//		User user = authMapper.findByEmail(email);
	//		if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
	//			throw new ApiException(ErrorCode.INVALID_CREDENTIALS);
	//		}
	//		return jwtUtil.generateToken(user.getEmail(), user.getRole());
	//	}

	@Transactional
	public Map<String, String> login(String email, String password) {

		User user = authMapper.findByEmail(email);
		if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
			throw new RuntimeException("Invalid credentials");
		}
		String accessToken = jwtUtil.generateAccessToken(user.getEmail(), user.getRole());
		String refreshToken = jwtUtil.generateRefreshToken();
		// 既存削除
		refreshTokenMapper.deleteByUserId(user.getId());
		// 保存
		RefreshToken token = new RefreshToken();
		token.setUserId(user.getId());
		token.setToken(refreshToken);
		token.setExpiryDate(LocalDateTime.now().plusDays(7));
		refreshTokenMapper.insert(token);
		return Map.of(
				"accessToken", accessToken,
				"refreshToken", refreshToken);
	}

	public String refresh(String refreshToken) {
		RefreshToken token = refreshTokenMapper.findByToken(refreshToken);
		
//		if (token == null || token.getExpiryDate().isBefore(LocalDateTime.now())) {
//			throw new RuntimeException("Invalid refresh token");
//		}
	    if (token == null) {
	        throw new RuntimeException("Token not found");
	    }

	    if (token.getExpiryDate().isBefore(LocalDateTime.now())) {
	        throw new RuntimeException("Token expired");
	    }
		
		
		
		User user = userMapper.findById(token.getUserId());
		return jwtUtil.generateAccessToken(user.getEmail(), user.getRole());
	}

}