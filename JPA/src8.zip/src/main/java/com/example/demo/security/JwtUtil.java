/**
 * 7で追加
 */
package com.example.demo.security;

import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {
	private final String SECRET = "9xT!kL2@pQ8#sV4$wX7^yZ1&bC6*D8eGhJmN0oPqRrStUvWxYz123456"; // 任意の32バイト英数字など
	private final long EXPIRATION = 1000 * 60 * 60; // 1時間

	public String generateToken(String email) {
		return Jwts.builder()
				.setSubject(email)
				.setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
				.signWith(Keys.hmacShaKeyFor(SECRET.getBytes()))
				.compact();
	}

	public String extractEmail(String token) {
		return Jwts.parserBuilder()
				.setSigningKey(SECRET.getBytes())
				.build()
				.parseClaimsJws(token)
				.getBody()
				.getSubject();
	}

	/**
	 * 8 アクセストークン作成
	 * @param email
	 * @return
	 */

	public String generateAccessToken(String email) {
		return createToken(email, 1000 * 60 * 15); // 15分
	}
	/**
	 * 8 リフレッシュトークンの作成
	 * @param email
	 * @return
	 */

	public String generateRefreshToken(String email) {
		return createToken(email, 1000 * 60 * 60 * 24 * 7); // 7日
	}

	/**
	 * 8　トークンの作成処理
	 * @param email
	 * @param expiry
	 * @return
	 */
	private String createToken(String email, long expiry) {
		return Jwts.builder()
				.setSubject(email)
				.setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + expiry))
				.signWith(Keys.hmacShaKeyFor(SECRET.getBytes()))
				.compact();
	}
}
