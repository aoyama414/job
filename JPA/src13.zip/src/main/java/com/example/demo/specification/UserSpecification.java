/**
 * 6
 */
package com.example.demo.specification;

import org.springframework.data.jpa.domain.Specification;

import com.example.demo.dto.UserSearchRequest;
import com.example.demo.entity.User;

public class UserSpecification {
    public static Specification<User> search(UserSearchRequest req) {
        return (root, query, cb) -> {
            var predicates = cb.conjunction();
            if (req.getName() != null) {
                predicates = cb.and(predicates,
                        cb.like(root.get("name"), "%" + req.getName() + "%"));
            }
            if (req.getEmail() != null) {
                predicates = cb.and(predicates,
                        cb.like(root.get("email"), "%" + req.getEmail() + "%"));
            }
            return predicates;
        };
    }
}
