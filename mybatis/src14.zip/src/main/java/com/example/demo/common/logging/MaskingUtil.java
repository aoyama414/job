/**
 * 14追加
 */
package com.example.demo.common.logging;

public class MaskingUtil {
	public static String maskEmail(String email) {
		if (email == null)
			return null;
		return email.replaceAll("(^.).*(@.*$)", "$1****$2");
	}

	public static String maskPassword(String password) {
		return "****";
	}
}